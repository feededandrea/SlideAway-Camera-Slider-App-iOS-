//
//  PuntoespecificoScreen.swift
//  SliderCamera
//
//  Created by Feede on 17/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth
import QuartzCore

var PETimer: Timer?

class PuntoespecificoScreen: UITableViewController, BluetoothSerialDelegate {
    
    
    func serialDidChangeState() {
        
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        
    }
    
    func serialDidReceiveString(_ message: String) {
        // add the received text to the textView, optionally with a line break at the end
        analizarTrama(message)
    }
    
    var perfilSeleccionado = "Default"
    
    @IBOutlet weak var btn_listo: UIButton!
    @IBOutlet weak var sw_asoulet: UISwitch!
    @IBOutlet weak var lbl_dscpunto: UILabel!
    @IBOutlet weak var lbl_esperando: UILabel!
    @IBOutlet weak var lbl_exactitudseg: UILabel!
    @IBOutlet weak var bar_exactitud: UIProgressView!
    @IBOutlet weak var outbtn_exactitud: UIStepper!

    var enviarDatos = true
    var enviarSet = false
  
  override func viewDidLoad() {
  super.viewDidLoad()
    
    let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
    perfilSeleccionado = perfilActual
    
      var f: Float=0;
      let bar = UserDefaults.standard.integer(forKey: "bar_exactitud")
      f = Float(bar)
      f = f / 10
      bar_exactitud.isUserInteractionEnabled=true
      bar_exactitud.setProgress( f, animated: false)
      outbtn_exactitud.value=Double(bar)
      let sw = UserDefaults.standard.string(forKey: "sw_punto") ?? "false"
    
      if(sw=="false"){
          sw_asoulet.setOn(false, animated: false)
          lbl_esperando.text="Esperando a que se posicione la cámara"
          btn_listo.setTitle("Listo", for: .normal)
          outbtn_exactitud.isEnabled=false
          bar_exactitud.isUserInteractionEnabled=false
          lbl_exactitudseg.isEnabled=false
          lbl_esperando.isEnabled=false
          btn_listo.isEnabled=false
      }
      else if(sw=="true"){
          let pos = UserDefaults.standard.string(forKey: "pos_fijada") ?? "false"
          sw_asoulet.setOn(true, animated: false)
          if(pos=="true"){
                 lbl_esperando.text="Posición fijada"
                 btn_listo.isEnabled=false
                 btn_listo.setTitle("Fijado", for: .normal)
                 outbtn_exactitud.isEnabled=false
                 bar_exactitud.isUserInteractionEnabled=false
                 lbl_exactitudseg.isEnabled=false
                 lbl_esperando.isEnabled=false
                 btn_listo.isEnabled=false
          }else{
          outbtn_exactitud.isEnabled=true
          bar_exactitud.isUserInteractionEnabled=true
          lbl_exactitudseg.isEnabled=true
          lbl_esperando.text="Esperando a que se posicione la cámara"
          btn_listo.setTitle("Listo", for: .normal)
          lbl_esperando.isEnabled=true
          btn_listo.isEnabled=false}
      }
  }
   
  
  var f: Float=0;
  
  
   @IBAction func btn_exactiud(_ sender: UIStepper) {
      f = Float(sender.value / 10)
      bar_exactitud.setProgress(f, animated: true)
      btn_listo.isEnabled=true
   }
  
  @IBAction func btn_posicion(_ sender: Any) {
      lbl_esperando.text="Posición fijada"
      UserDefaults.standard.set("true", forKey: "pos_fijada")
      btn_listo.isEnabled=false
      btn_listo.setTitle("Fijado", for: .normal)
      outbtn_exactitud.isEnabled=false
      bar_exactitud.isUserInteractionEnabled=false
      lbl_exactitudseg.isEnabled=false
      lbl_esperando.isEnabled=false
      btn_listo.isEnabled=false
  }
  
  @IBAction func sw_punto(_ sender: UISwitch) {
       if (sender.isOn) {
           peWeel.startAnimating()
           UserDefaults.standard.set(0, forKey: "bar_exactitud")
           bar_exactitud.setProgress(Float(0), animated: true)
           UserDefaults.standard.set("false", forKey: "pos_fijada")
           UserDefaults.standard.set("true", forKey: "sw_punto")
           outbtn_exactitud.isEnabled=true
           bar_exactitud.isUserInteractionEnabled=true
           lbl_exactitudseg.isEnabled=true
           lbl_esperando.text="Esperando a que se posicione la cámara"
           btn_listo.setTitle("Listo", for: .normal)
           lbl_esperando.isEnabled=true
           btn_listo.isEnabled=false
           self.tableView.beginUpdates()
           self.tableView.endUpdates()

           //hace algo cuando se enciende
       }
       else{
           peWeel.stopAnimating()
           lbl_esperando.text="Esperando a que se posicione la cámara"
           btn_listo.setTitle("Listo", for: .normal)
           UserDefaults.standard.set("false", forKey: "pos_fijada")
           UserDefaults.standard.set("false", forKey: "sw_punto")
           outbtn_exactitud.isEnabled=false
           bar_exactitud.isUserInteractionEnabled=false
           lbl_exactitudseg.isEnabled=false
           lbl_esperando.isEnabled=false
           btn_listo.isEnabled=false
           self.tableView.beginUpdates()
           self.tableView.endUpdates()
           
           //hace algo cuando se apaga
       }
   }
    
    func analizarTrama(_ message: String){
        enviarDatos = false
        var trama: [String] = []
        var tramaAnalizada: [String] = []
        trama.append(contentsOf: message.map { String($0) })
        
        enum estates { case INICIO, carCARACTERISTICA1, carCARACTERISTICA2, VALOR1, VALOR2, VALOR3, CRS, FIN }
        enum s { case SI, NO }
        var estate = estates.INICIO
        var requiereSegundaCar = s.NO
        var requiereValor2 = s.NO
        var requiereValor3 = s.NO
        var iAnalizada = 0
        for caracter in trama {
            switch estate {
                case estates.INICIO:
                    if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.carCARACTERISTICA1:
                    if(caracter == "I"){
                        iAnalizada = iAnalizada + 1
                        estate = estates.carCARACTERISTICA2
                        requiereSegundaCar = s.SI
                        tramaAnalizada.append("I")
                }else if(caracter == "L"){
                    iAnalizada = iAnalizada + 1
                    estate = estates.VALOR1
                    requiereSegundaCar = s.NO
                    tramaAnalizada.append("L")
                }else if(caracter == "$"){
                    iAnalizada = 0
                    tramaAnalizada.removeAll()
                    estate = estates.carCARACTERISTICA1
                    tramaAnalizada.append("$")
                }
                break
                case estates.carCARACTERISTICA2:
                    if(caracter == "C" && requiereSegundaCar == s.SI){
                        iAnalizada = iAnalizada + 1
                        estate = estates.VALOR1
                        requiereValor2 = s.SI
                        requiereValor3 = s.SI
                        tramaAnalizada.append("C")
                    }else if(caracter == "S" && requiereSegundaCar == s.SI){
                        iAnalizada = iAnalizada + 1
                        estate = estates.VALOR1
                        requiereValor2 = s.SI
                        requiereValor3 = s.SI
                        tramaAnalizada.append("S")
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.removeAll()
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR1:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        if(requiereValor2 == s.SI){
                            estate = estates.VALOR2
                        }
                        else{
                            estate = estates.CRS
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR2:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        if(requiereValor3 == s.SI){
                            estate = estates.VALOR3
                        }
                        else{
                            estate = estates.CRS
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR3:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        estate = estates.CRS
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.CRS:
                    if(caracter == "e"){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append("e")
                        estate = estates.FIN
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.FIN:
                    if(caracter == "!"){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append("!")
                        estate = estates.INICIO
                        print("Trama completada")
                        if(tramaAnalizada[1] == "I" && tramaAnalizada[2] == "C"){
                            let numero:Int = Int(tramaAnalizada[3] + tramaAnalizada[4] + tramaAnalizada[5]) ?? 0
                            
                            print("Inclinación Cámara: " + numero.description + " grados" )
                            UserDefaults.standard.set( numero.description + "º Grados", forKey: "inclinacionCamara")
                        }
                        if(tramaAnalizada[1] == "I" && tramaAnalizada[2] == "S"){
                            let numero:Int = Int(tramaAnalizada[3] + tramaAnalizada[4] + tramaAnalizada[5]) ?? 0
                            
                            print("Inclinación Slider: " + numero.description + " grados" )
                            
                            UserDefaults.standard.set( numero.description + "º Grados", forKey: "inclinacionSlider")
                        }
                        if(tramaAnalizada[1] == "L"){
                            
                            if(tramaAnalizada[3]=="1"){
                                UserDefaults.standard.set(1, forKey: "loopEstado")
                            }
                            else{
                                UserDefaults.standard.set(0, forKey: "loopEstado")
                            }
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                }
            enviarDatos = true
                
        }
    }
    
    @IBOutlet weak var peWeel: UIActivityIndicatorView!
    @objc func PEserialInfoSend(){
        if(enviarDatos == true){
            if (sw_asoulet.isOn) {
            if(enviarSet == true){
                peWeel.stopAnimating()
                let n = Int(f*10)
                string = String(format: "%02d", n) // returns "100"
                serial.sendMessageToDevice("$PES" + string + "e!")
                UserDefaults.standard.set(n, forKey: "bar_exactitud")
                enviarSet = false
                }
            }
          else{
              serial.sendMessageToDevice("$PERe!")
            }
            let joystick_desde = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_desde") ?? "App"
            
            if(joystick_desde == "App"){
                serial.sendMessageToDevice("$JAe!")
            }
            else{
                serial.sendMessageToDevice("$JRe!")
            }
        }
    }
}
