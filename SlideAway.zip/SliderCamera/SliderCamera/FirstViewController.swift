//
//  FirstViewController.swift
//  SliderCamera
//
//  Created by Feede on 10/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import UIKit


class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var vel_bar: UIProgressView!
    
   var oldbarvalue: Float = 0
   var sendedbarvalue: Float = 0
   var f: Float = 0
    @IBOutlet weak var btn_listo: UIButton!
    
    @IBOutlet weak var lbl_dscpunto: UILabel!
    @IBOutlet weak var lbl_esperando: UILabel!
    
    @IBAction func btn_posicion(_ sender: Any) {
        lbl_esperando.text="Posición fijada"
        btn_listo.isEnabled=false
        btn_listo.setTitle("Fijado", for: .normal)
        lbl_esperando.isEnabled=false
    }
    @IBOutlet weak var btn_sendspeedp: UIButton!
    @IBOutlet weak var pro_velocidad: UIProgressView!
    
    @IBAction func btn_sendspeed(_ sender: Any) {
        sendedbarvalue=f;
        btn_sendspeedp.isEnabled = false
    }
    @IBAction func btn_velocidad(_ sender: UIStepper) {
        f = Float(sender.value / 10)
        vel_bar.setProgress(f, animated: true)
        oldbarvalue=f
        if(oldbarvalue==sendedbarvalue){
            btn_sendspeedp.isEnabled = false
        }
        else{
            btn_sendspeedp.isEnabled = true
        }
    }
    
    @IBAction func sw_punto(_ sender: UISwitch) {
        if (sender.isOn) {
            lbl_esperando.text="Esperando a que se posicione la cámara"
            btn_listo.setTitle("Listo", for: .normal)
            lbl_esperando.isEnabled=true
            btn_listo.isEnabled=true
            lbl_dscpunto.isHidden=true
            //hace algo cuando se enciende
        }
        else{
            btn_listo.setTitle("", for: .normal)
            lbl_esperando.text=""
            lbl_esperando.isEnabled=false
            btn_listo.isEnabled=false
            lbl_dscpunto.isHidden=false
            //hace algo cuando se apaga
        }
    }

    
    
}

