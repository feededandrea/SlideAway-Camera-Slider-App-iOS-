//
//  SecondViewController.swift
//  SliderCamera
//
//  Created by Feede on 10/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

