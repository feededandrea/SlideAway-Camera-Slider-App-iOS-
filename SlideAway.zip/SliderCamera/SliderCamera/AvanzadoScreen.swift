//
//  AvanzadoScreen.swift
//  SliderCamera
//
//  Created by Feede on 15/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth

var AvanTimer: Timer?
var SerialTimer: Timer?

var enviarVelocidad = false
var movimientoLoop = false
var enviarDatos = true
class AvanzadoScreen: UITableViewController, BluetoothSerialDelegate{
    
    func serialDidChangeState() {
        reloadView()
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        reloadView()
    }
    
    func serialDidReceiveString(_ message: String) {
        // add the received text to the textView, optionally with a line break at the end
        analizarTrama(message)
    }
    
    @IBOutlet weak var inclinacionSlider: UILabel!
    @IBOutlet weak var inclinacionCamara: UILabel!
    func analizarTrama(_ message: String){
        enviarDatos = false
        var trama: [String] = []
        var tramaAnalizada: [String] = []
        trama.append(contentsOf: message.map { String($0) })
        
        enum estates { case INICIO, carCARACTERISTICA1, carCARACTERISTICA2, VALOR1, VALOR2, VALOR3, CRS, FIN }
        enum s { case SI, NO }
        var estate = estates.INICIO
        var requiereSegundaCar = s.NO
        var requiereValor2 = s.NO
        var requiereValor3 = s.NO
        var iAnalizada = 0
        for caracter in trama {
            switch estate {
                case estates.INICIO:
                    if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.carCARACTERISTICA1:
                    if(caracter == "I"){
                        iAnalizada = iAnalizada + 1
                        estate = estates.carCARACTERISTICA2
                        requiereSegundaCar = s.SI
                        tramaAnalizada.append("I")
                }else if(caracter == "L"){
                    iAnalizada = iAnalizada + 1
                    estate = estates.VALOR1
                    requiereSegundaCar = s.NO
                    tramaAnalizada.append("L")
                }else if(caracter == "$"){
                    iAnalizada = 0
                    tramaAnalizada.removeAll()
                    estate = estates.carCARACTERISTICA1
                    tramaAnalizada.append("$")
                }
                break
                case estates.carCARACTERISTICA2:
                    if(caracter == "C" && requiereSegundaCar == s.SI){
                        iAnalizada = iAnalizada + 1
                        estate = estates.VALOR1
                        requiereValor2 = s.SI
                        requiereValor3 = s.SI
                        tramaAnalizada.append("C")
                    }else if(caracter == "S" && requiereSegundaCar == s.SI){
                        iAnalizada = iAnalizada + 1
                        estate = estates.VALOR1
                        requiereValor2 = s.SI
                        requiereValor3 = s.SI
                        tramaAnalizada.append("S")
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.removeAll()
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR1:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        if(requiereValor2 == s.SI){
                            estate = estates.VALOR2
                        }
                        else{
                            estate = estates.CRS
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR2:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        if(requiereValor3 == s.SI){
                            estate = estates.VALOR3
                        }
                        else{
                            estate = estates.CRS
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.VALOR3:
                    if("0" ... "9").contains(caracter){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append(caracter)
                        estate = estates.CRS
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.CRS:
                    if(caracter == "e"){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append("e")
                        estate = estates.FIN
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                case estates.FIN:
                    if(caracter == "!"){
                        iAnalizada = iAnalizada + 1
                        tramaAnalizada.append("!")
                        estate = estates.INICIO
                        print("Trama completada")
                        if(tramaAnalizada[1] == "I" && tramaAnalizada[2] == "C"){
                            let numero:Int = Int(tramaAnalizada[3] + tramaAnalizada[4] + tramaAnalizada[5]) ?? 0
                            
                            print("Inclinación Cámara: " + numero.description + " grados" )
                            UserDefaults.standard.set( numero.description + "º Grados", forKey: "inclinacionCamara")
                            
                            inclinacionCamara.text = numero.description + "º Grados"
                        }
                        if(tramaAnalizada[1] == "I" && tramaAnalizada[2] == "S"){
                            let numero:Int = Int(tramaAnalizada[3] + tramaAnalizada[4] + tramaAnalizada[5]) ?? 0
                            
                            print("Inclinación Slider: " + numero.description + " grados" )
                            inclinacionSlider.text = numero.description + "º Grados"
                            UserDefaults.standard.set( numero.description + "º Grados", forKey: "inclinacionSlider")
                        }
                        if(tramaAnalizada[1] == "L"){
                            
                            if(tramaAnalizada[3]=="1"){
                                swLoop.setOn(true, animated: true)
                                UserDefaults.standard.set(1, forKey: "loopEstado")
                            }
                            else{
                                swLoop.setOn(false, animated: true)
                                UserDefaults.standard.set(0, forKey: "loopEstado")
                            }
                        }
                    }else if(caracter == "$"){
                        iAnalizada = 0
                        tramaAnalizada.removeAll()
                        estate = estates.carCARACTERISTICA1
                        tramaAnalizada.append("$")
                }
                break
                }
            enviarDatos = true
                
        }
    }
    
    var perfilSeleccionado: String! = "Default"
  @IBOutlet weak var outbtn_velocidad: UIStepper!
    @IBOutlet weak var tlEstadolbl: UILabel!
    
    func estadotl() {
        let tlEstado = UserDefaults.standard.string(forKey: "tlEstado") ?? "Sin comenzar"
        tlEstadolbl.text = tlEstado
    }
    @IBOutlet weak var cellTimelapse: UITableViewCell!
    @IBOutlet weak var lblTimelapse: UILabel!
    @IBOutlet weak var swLoop: UISwitch!
    @IBOutlet weak var cellPuntoEspecifico: UITableViewCell!
    @IBOutlet weak var lblPuntoEspecifico: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @objc func reloadView() {
        // in case we're the visible view again
        serial.delegate = self
        
        if serial.isReady {
            statusLabel.text = "Actualmente te encuentras conectado"
            statusLabel.textColor = .systemGreen
            cellPuntoEspecifico.isUserInteractionEnabled = true
            lblPuntoEspecifico.isEnabled = true
            outbtn_velocidad.isEnabled = true
            swLoop.isEnabled = true
            cellTimelapse.isUserInteractionEnabled = true
            lblTimelapse.isEnabled = true
            
        } else if serial.centralManager.state == .poweredOn {
            statusLabel.text = "Actualmente te encuentras desconectado"
            statusLabel.textColor = .label
            cellPuntoEspecifico.isUserInteractionEnabled = false
            lblPuntoEspecifico.isEnabled = false
            outbtn_velocidad.isEnabled = false
            swLoop.isEnabled = false
            cellTimelapse.isUserInteractionEnabled = false
            lblTimelapse.isEnabled = false
        } else {
            statusLabel.text = "Actualmente te encuentras desconectado"
            statusLabel.textColor = .label
            cellPuntoEspecifico.isUserInteractionEnabled = false
            lblPuntoEspecifico.isEnabled = false
            outbtn_velocidad.isEnabled = false
            swLoop.isEnabled = false
            cellTimelapse.isUserInteractionEnabled = false
            lblTimelapse.isEnabled = false
        }
    }
    
    override func viewDidLoad() {
        UserDefaults.standard.set(0,forKey: "loopEstado")
        super.viewDidLoad()
        UserDefaults.standard.set( "0º Grados", forKey: "inclinacionSlider")
        UserDefaults.standard.set( "0º Grados", forKey: "inclinacionCamara")
        estadotl()
        reloadView()
        AvanTimer?.invalidate()
        AvanTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
               perfilSeleccionado = perfilActual
        let ult_vel = UserDefaults.standard.float(forKey: self.perfilSeleccionado + "ultima_velocidadenviada")
        vel_bar.setProgress(ult_vel, animated: false)
        outbtn_velocidad.setValue(Int(ult_vel*10), forKey: "value")
         // Do any additional setup after loading the view.
        
        let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
        
        let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
        lblretrasoEstablecido.text = loop_delaytime + " " + loop_unidadtiempo
        
        
    }
    @IBOutlet weak var loopDetenerseLabel: UILabel!
    
    override func viewDidAppear(_ animated: Bool) {
        
        if(serial.isReady){
            SerialTimer?.invalidate()
            SerialTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(serialInfoSend), userInfo: nil, repeats: true)
        }
        
        let shortcutTimelapse = UserDefaults.standard.integer(forKey: "shortcutTimelapse")
         
         if(serial.isReady){
             if( shortcutTimelapse == 1){
                 
                 
                 let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                 let newViewController = storyBoard.instantiateViewController(withIdentifier: "timelapseScreen") as! TimelapseScreen
                 self.navigationController?.pushViewController(newViewController, animated: true)
                         
                 UserDefaults.standard.set(0, forKey: "shortcutTimelapse")
             }
         }
        
        estadotl()
        reloadView()
        AvanTimer?.invalidate()
               AvanTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
               perfilSeleccionado = perfilActual
        let ult_vel = UserDefaults.standard.float(forKey: self.perfilSeleccionado + "ultima_velocidadenviada")
        vel_bar.setProgress(ult_vel, animated: false)
        outbtn_velocidad.setValue(Int(ult_vel*10), forKey: "value")
         // Do any additional setup after loading the view.
        
        let loopEstado = UserDefaults.standard.integer(forKey: "loopEstado")
        
        if(loopEstado == 1){
            swLoop.setOn(true, animated: false)
        }
        else{
            swLoop.setOn(false, animated: false)
        }
        
        if(!swLoop.isOn){
            let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
            
            let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
            lblretrasoEstablecido.text = loop_delaytime + " " + loop_unidadtiempo.lowercased()
            
            let loopDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_Detenerse") ?? "Nunca"
            
            let loopunidadDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse") ?? "Segundos"
           
            if(loopDetenerse != "Nunca"){
            loopDetenerseLabel.text = loopDetenerse + " " + loopunidadDetenerse.lowercased()
            }
            else{
                loopDetenerseLabel.text = "Nunca"
            }
        
        }
        inclinacionSlider.text = UserDefaults.standard.string(forKey: "inclinacionSlider" ) ?? "0º Grados"
               
        inclinacionCamara.text = UserDefaults.standard.string( forKey: "inclinacionCamara" ) ?? "0º Grados"
               
    }
     @IBOutlet weak var vel_bar: UIProgressView!
     
    var oldbarvalue: Float = 0
    var sendedbarvalue: Float = 0
    var f: Float = 0
    
    @IBOutlet weak var lblretrasoEstablecido: UILabel!
    
     @IBOutlet weak var btn_sendspeedp: UIButton!
     @IBOutlet weak var pro_velocidad: UIProgressView!
     
     @IBAction func btn_sendspeed(_ sender: Any) {
        enviarVelocidad = true
        velWeel.startAnimating()
     }
     @IBAction func btn_velocidad(_ sender: UIStepper) {
         f = Float(sender.value / 10)
         vel_bar.setProgress(f, animated: true)
         oldbarvalue=f
         if(oldbarvalue==sendedbarvalue){
             btn_sendspeedp.isEnabled = false
         }
         else{
             btn_sendspeedp.isEnabled = true
         }
     }
    
    @IBAction func swActionloop(_ sender: Any) {
        
        let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
        
        let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
             lblretrasoEstablecido.text = loop_delaytime + " " + loop_unidadtiempo.lowercased()
             
        let loopDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_Detenerse") ?? "Nunca"
             
        let loopunidadDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse") ?? "Segundos"
            
        if(loopDetenerse != "Nunca"){
            loopDetenerseLabel.text = loopDetenerse + " " + loopunidadDetenerse.lowercased()
        }
        else{
            loopDetenerseLabel.text = "Nunca"
        }
        movimientoLoop=true
        swWeel.startAnimating()
    }
    
    @objc func runTimedCode(){
        estadotl()
    }
    @objc func serialInfoSend(){
        if(enviarDatos == true){
            if(enviarVelocidad==true){
                velWeel.stopAnimating()
                sendedbarvalue = f;
                let n = Int(f*10)
                string = String(format: "%02d", n) // returns "100"
                serial.sendMessageToDevice("$V" + string + "e!")
                print("$V" + string + "e!")
                btn_sendspeedp.isEnabled = false
                UserDefaults.standard.set(f, forKey: self.perfilSeleccionado + "ultima_velocidadenviada")
                enviarVelocidad = false
            }
            
            if(movimientoLoop==true){

                let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
                      
                let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
                      
                let loop_unidadtiempoDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse") ?? "Segundos"
                       
                let loop_Detenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_Detenerse") ?? "Nunca"
                
                var unidadDelay = "S"
                
                if(loop_unidadtiempo == "Segundos"){
                    unidadDelay = "S"
                }
                else if(loop_unidadtiempo == "Minutos"){
                    unidadDelay = "M"
                }
                else if(loop_unidadtiempo == "Horas"){
                    unidadDelay = "H"
                }
                
                var unidadDetenerse = "S"
                
                if(loop_unidadtiempoDetenerse == "Segundos"){
                    unidadDetenerse = "S"
                }
                else if(loop_unidadtiempoDetenerse == "Minutos"){
                    unidadDetenerse = "M"
                }
                else if(loop_unidadtiempoDetenerse == "Horas"){
                    unidadDetenerse = "H"
                }
                
                let numberDelay = Int(loop_delaytime) ?? 0
                let Delay = String(format: "%02d", numberDelay) // returns "00"
                var numberDetenerse = 0
                var Detenerse = "NC"
                if(loop_Detenerse != "Nunca"){
                    numberDetenerse = Int(loop_Detenerse) ?? 0
                    Detenerse = String(format: "%02d", numberDetenerse) // returns "00"
                }
                if(swLoop.isOn){
                    serial.sendMessageToDevice("$L1" + Delay + unidadDelay + Detenerse  +  unidadDetenerse + "e!")
                    swWeel.stopAnimating()
                    UserDefaults.standard.set(1, forKey: "loopEstado")
                }
                else{
                    serial.sendMessageToDevice("$L0e!")
                    swWeel.stopAnimating()
                    UserDefaults.standard.set(0, forKey: "loopEstado")
                }
                movimientoLoop=false
            }
            
            let joystick_desde = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_desde") ?? "App"
            
            if(joystick_desde == "App"){
                serial.sendMessageToDevice("$JAe!")
            }
            else{
                serial.sendMessageToDevice("$JRe!")
            }
        }
    }
    @IBOutlet weak var swWeel: UIActivityIndicatorView!
    @IBOutlet weak var velWeel: UIActivityIndicatorView!
    
}
