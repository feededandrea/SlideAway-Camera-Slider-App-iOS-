//
//  JoystickScreen.swift
//  SliderCamera
//
//  Created by Feede on 22/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
import QuartzCore

class JoystickScreen: UIViewController {
    
    
    
    @IBOutlet weak var joysti: SKView!
    @IBOutlet weak var joysti2: SKView!
    
    @IBOutlet weak var joystick1: UILabel!
    @IBOutlet weak var joystick2: UILabel!
    
     override func viewDidLoad() {
       super.viewDidLoad()
       // Do any additional setup after loading the view, typically from a nib.
       setupViews()
     }
    override func viewDidAppear(_ animated: Bool) {
        setupViews()
    }
     override func didReceiveMemoryWarning() {
       super.didReceiveMemoryWarning()
       // Dispose of any resources that can be recreated.
     }

     var perfilSeleccionado: String! = "Default"
    
     fileprivate func setupViews() {
        
        let joystick_desde = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_desde") ?? "App"
        
        if(joystick_desde=="App"){
            joysti.isUserInteractionEnabled=true
            joysti2.isUserInteractionEnabled=true
            
        }
        else{
            joysti.isUserInteractionEnabled=false
            joysti2.isUserInteractionEnabled=false
        }
        
        
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
        perfilSeleccionado = perfilActual
        
        let joystick_orden = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_orden") ?? "Normal"
        
        joysti.isMultipleTouchEnabled = true
        joysti.allowsTransparency=true
        joysti.backgroundColor = UIColor.clear
        joysti.ignoresSiblingOrder = true
    
        joysti2.isMultipleTouchEnabled = true
        joysti2.allowsTransparency=true
        joysti2.backgroundColor = UIColor.clear
        joysti2.ignoresSiblingOrder = true

        if(joystick_orden=="Normal"){
            let scene = GameplayXonly(size: joysti.bounds.size)
            scene.backgroundColor = UIColor.clear
            joysti.presentScene(scene)
            joystick1.text = "Slider"
            joystick2.text = "Cámara"
            joystick2.layer.cornerRadius = 15
            joystick1.layer.cornerRadius = 15
            joystick2.layer.masksToBounds = true
            joystick1.layer.masksToBounds = true
            
            let scene2 = Gameplay(size: joysti2.bounds.size)
            scene2.backgroundColor = UIColor.clear
            joysti2.presentScene(scene2)
        }
        else{
            let scene = Gameplay(size: joysti.bounds.size)
            scene.backgroundColor = UIColor.clear
            joysti.presentScene(scene)
            joystick2.text = "Slider"
            joystick1.text = "Cámara"
            joystick2.layer.cornerRadius = 15
            joystick1.layer.cornerRadius = 15
            joystick2.layer.masksToBounds = true
            joystick1.layer.masksToBounds = true
            let scene2 = GameplayXonly(size: joysti2.bounds.size)
            scene2.backgroundColor = UIColor.clear
            joysti2.presentScene(scene2)
        }
       //    skView.showsFPS = true
       //    skView.showsNodeCount = true
       //    skView.showsPhysics = true
     }
    
    

    
}

class Gameplay: SKScene {
    
    let velocityMultiplier: CGFloat = 0.12
       
       enum NodesZPosition: CGFloat {
         case background, hero, joystick
       }
    
    
    lazy var background: SKSpriteNode = {
      var sprite = SKSpriteNode(imageNamed: "Background")
      sprite.position = CGPoint.zero
      sprite.zPosition = NodesZPosition.background.rawValue
      
      return sprite
    }()
    
    lazy var hero: SKSpriteNode = {
      var sprite = SKSpriteNode(imageNamed: "Hero")
      sprite.position = CGPoint.zero
      sprite.zPosition = NodesZPosition.hero.rawValue
      //sprite.scaleTo(screenWidthPercentage: 0.23)
      return sprite
    }()
    
    
    override func didMove(to view: SKView) {
      setupNodes()
      setupJoystick()
    }
    
    func setupNodes() {
      anchorPoint = CGPoint(x: 0, y: 0)
      //addChild(background)
      //addChild(hero)
    }
       
    lazy var analogJoystick: AnalogJoystick = {
       let js = AnalogJoystick(diameter: 105, colors: nil, images: (substrate: #imageLiteral(resourceName: "jSubstrate"), stick: #imageLiteral(resourceName: "jStick")))
       js.position = CGPoint(x: 0 + js.radius + 45, y: 0 + js.radius + 45)
       js.zPosition = NodesZPosition.joystick.rawValue
       return js
     }()
    
  
    
    func setupJoystick() {
       addChild(analogJoystick)
        
        
        analogJoystick.stopHandler = {
            var x = (((self.hero.position.x + (self.analogJoystick.data.velocity.x * self.velocityMultiplier)) * 40.47))
            x = x + 255
            x = x / 2
            x = x.rounded()
            let intx: Int = Int(x)
            
            var y = (((self.hero.position.y + (self.analogJoystick.data.velocity.y * self.velocityMultiplier)) * 40.47))
            y = y + 255
            y = y / 2
            y = y.rounded()
            let inty: Int = Int(y)
           
            JoystickRealScreen.setJoystick(joystickX: intx.description, joystickY: inty.description)
                      
        }
        
        analogJoystick.trackingHandler = { [unowned self] data in
           // print("X: " + (self.hero.position.x + (data.velocity.x * self.velocityMultiplier)).description)
            //print("Y: " +  (self.hero.position.y + (data.velocity.y * self.velocityMultiplier)).description)
            
            var x = (((self.hero.position.x + (data.velocity.x * self.velocityMultiplier)) * 40.47))
            x = x + 255
            x = x / 2
            x = x.rounded()
            let intx: Int = Int(x)
            
            var y = (((self.hero.position.y + (data.velocity.y * self.velocityMultiplier)) * 40.47))
            y = y + 255
            y = y / 2
            y = y.rounded()
            let inty: Int = Int(y)
            
            JoystickRealScreen.setJoystick(joystickX: intx.description, joystickY: inty.description)
                      
            self.hero.zRotation = data.angular
                    
            }
       
     }
}


class GameplayXonly: SKScene {
    
    let velocityMultiplier: CGFloat = 0.12
       
       enum NodesZPosition: CGFloat {
         case background, hero, joystick
       }
    
    
    lazy var background: SKSpriteNode = {
      var sprite = SKSpriteNode(imageNamed: "Background")
      sprite.position = CGPoint.zero
      sprite.zPosition = NodesZPosition.background.rawValue
      
      return sprite
    }()
    
    lazy var hero: SKSpriteNode = {
      var sprite = SKSpriteNode(imageNamed: "Hero")
      sprite.position = CGPoint.zero
      sprite.zPosition = NodesZPosition.hero.rawValue
      return sprite
    }()
    
    
    override func didMove(to view: SKView) {
      setupNodes()
      setupJoystickXonly()
    }
    
    func setupNodes() {
      anchorPoint = CGPoint(x: 0, y: 0)
    }
       
    lazy var analogJoystickXonly: AnalogJoystickXonly = {
       let js = AnalogJoystickXonly(diameter: 105, colors: nil, images: (substrate: #imageLiteral(resourceName: "jSubstrate"), stick: #imageLiteral(resourceName: "jStick")))
       js.position = CGPoint(x: 0 + js.radius + 45, y: 0 + js.radius + 45)
       js.zPosition = NodesZPosition.joystick.rawValue
       return js
     }()
    
    

    
    func setupJoystickXonly() {
       addChild(analogJoystickXonly)
        
        
        analogJoystickXonly.stopHandler = {
            var x = (((self.hero.position.x + (self.analogJoystickXonly.data.velocity.x * self.velocityMultiplier)) * 40.47))
            x = x + 255
            x = x / 2
            x = x.rounded()
            let intx: Int = Int(x)
            JoystickRealScreen.setJoystickOnlyX(joystickXOnlyX: intx.description)
        }
    
        analogJoystickXonly.trackingHandler = {[unowned self] data in
            //print("X: " + (self.hero.position.x + (data.velocity.x * self.velocityMultiplier)).description)
            var x = (((self.hero.position.x + (data.velocity.x * self.velocityMultiplier)) * 40.47))
            x = x + 255
            x = x / 2
            x = x.rounded()
            let intx: Int = Int(x)
            JoystickRealScreen.setJoystickOnlyX(joystickXOnlyX: intx.description)
            
            self.hero.zRotation = data.angular
            
            
            
            }
       
     }
    

}
