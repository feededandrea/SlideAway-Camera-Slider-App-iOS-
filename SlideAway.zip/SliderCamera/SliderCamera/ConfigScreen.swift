//
//  ConfigScreen.swift
//  SliderCamera
//
//  Created by Feede on 14/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth


var SettingsTimer: Timer?



class ConfigScreen: UITableViewController, BluetoothSerialDelegate, UITextFieldDelegate {
    func serialDidChangeState() {
        reloadView()
    }

    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        reloadView()
    }
    
    func serialDidReceiveString(_ message: String) {
          // add the received text to the textView, optionally with a line break at the end
          analizarTrama(message)
    }
    
    func analizarTrama(_ message: String){
           enviarDatos = false
           var trama: [String] = []
           var tramaAnalizada: [String] = []
           trama.append(contentsOf: message.map { String($0) })
           
           enum estates { case INICIO, carCARACTERISTICA1, VALOR1, CRS, FIN }
           enum s { case SI, NO }
           var estate = estates.INICIO
           var iAnalizada = 0
           for caracter in trama {
               switch estate {
                   case estates.INICIO:
                       if(caracter == "$"){
                           iAnalizada = 0
                           tramaAnalizada.removeAll()
                           estate = estates.carCARACTERISTICA1
                           tramaAnalizada.append("$")
                   }
                   break
                   case estates.carCARACTERISTICA1:
                     if(caracter == "L"){
                       iAnalizada = iAnalizada + 1
                       estate = estates.VALOR1
                       tramaAnalizada.append("L")
                   }else if(caracter == "$"){
                       iAnalizada = 0
                       tramaAnalizada.removeAll()
                       estate = estates.carCARACTERISTICA1
                       tramaAnalizada.append("$")
                   }
                   break
                  
                   case estates.VALOR1:
                       if("0" ... "9").contains(caracter){
                           iAnalizada = iAnalizada + 1
                           tramaAnalizada.append(caracter)
                           estate = estates.CRS
                       }else if(caracter == "$"){
                           iAnalizada = 0
                           tramaAnalizada.removeAll()
                           estate = estates.carCARACTERISTICA1
                           tramaAnalizada.append("$")
                   }
                   break
                   case estates.CRS:
                       if(caracter == "e"){
                           iAnalizada = iAnalizada + 1
                           tramaAnalizada.append("e")
                           estate = estates.FIN
                       }else if(caracter == "$"){
                           iAnalizada = 0
                           tramaAnalizada.removeAll()
                           estate = estates.carCARACTERISTICA1
                           tramaAnalizada.append("$")
                   }
                   break
                   case estates.FIN:
                       if(caracter == "!"){
                           iAnalizada = iAnalizada + 1
                           tramaAnalizada.append("!")
                           estate = estates.INICIO
                           print("Trama completada")
                           if(tramaAnalizada[1] == "L"){
                               if(tramaAnalizada[3]=="1"){
                                  UserDefaults.standard.set(1, forKey: "loopEstado")
                               }
                               else{
                                   UserDefaults.standard.set(0, forKey: "loopEstado")
                               }
                           }
                       }else if(caracter == "$"){
                           iAnalizada = 0
                           tramaAnalizada.removeAll()
                           estate = estates.carCARACTERISTICA1
                           tramaAnalizada.append("$")
                   }
                   break
            }
               enviarDatos = true
                   
           }
       }
      
    var perfilSeleccionado: String! = "Default"
    @IBOutlet var tableconfigview: UITableView!
    var alertTextFiled: UITextField?
  
    @IBOutlet weak var loopDetenerseOut: UIButton!
    @IBOutlet weak var loopUnidadDetenerse: UIButton!
    @IBOutlet weak var textbtn_timelapsestart: UIButton!
    
    @IBOutlet weak var outbtn_joystickdesde: UIButton!
    @IBAction func btn_joystickdesde(_ sender: Any) {
    }
    @IBAction func btn_timelapsestart(_ sender: Any) {
    }
    
    @IBOutlet weak var txtbtn_conexiontimeout: UIButton!
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
              if indexPath.section == 1 && indexPath.row == 2 {
                    txtbtn_conexiontimeout.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
                        let sheet = UIAlertController(title: "TimeOut", message: nil, preferredStyle: .actionSheet)
                        let nunca=UIAlertAction(title: "Nunca", style: .default){
                            (action) in self.txtbtn_conexiontimeout.setTitle("Nunca", for: .normal)
                            UserDefaults.standard.set("Nunca", forKey: self.perfilSeleccionado + "timeout")
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        let min10=UIAlertAction(title: "10 minutos", style: .default){
                            (action) in self.txtbtn_conexiontimeout.setTitle("10 minutos", for: .normal)
                            UserDefaults.standard.set("10 minutos", forKey: self.perfilSeleccionado + "timeout")
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        let min30=UIAlertAction(title: "30 minutos", style: .default){
                            (action) in self.txtbtn_conexiontimeout.setTitle("30 minutos", for: .normal)
                            UserDefaults.standard.set("30 minutos", forKey: self.perfilSeleccionado + "timeout")
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        let h1=UIAlertAction(title: "1 hora", style: .default){
                            (action) in self.txtbtn_conexiontimeout.setTitle("1 hora", for: .normal)
                            UserDefaults.standard.set("1 hora", forKey: self.perfilSeleccionado + "timeout")
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        let h2=UIAlertAction(title: "2 horas", style: .default){
                            (action) in self.txtbtn_conexiontimeout.setTitle("2 horas", for: .normal)

                            UserDefaults.standard.set("2 horas", forKey: self.perfilSeleccionado + "timeout")
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                            (action) in self.txtbtn_conexiontimeout.setTitle(self.txtbtn_conexiontimeout.title(for: .normal), for: .normal)
                            if let index = self.tableView.indexPathForSelectedRow{
                            self.tableView.deselectRow(at: index, animated: true)
                            }
                        }
                        sheet.addAction(nunca)
                        sheet.addAction(min10)
                        sheet.addAction(min30)
                        sheet.addAction(h1)
                        sheet.addAction(h2)
                        sheet.addAction(cancelar)
                        present(sheet,animated: true, completion: nil)

                
        }
        
        if indexPath.section == 2 && indexPath.row == 0 {

            txtbtn_looptiempouni.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Retraso", message: nil, preferredStyle: .actionSheet)
            
            let tie=UIAlertAction(title: "Determinar tiempo", style: .default){
                (action) in

              self.cualTextfiled = 0
              //1. Create the alert controller.
              let alert = UIAlertController(title: "Ingrese tiempo en " + (self.txtbtn_looptiempouni.title(for: .normal) ?? "Segundos").lowercased() , message: nil, preferredStyle: .alert)

              //2. Add the text field. You can configure it however you need.
              alert.addTextField(configurationHandler: self.alertTextFiled)

              // 3. Grab the value from the text field, and print it when the user clicks OK.
              let okAction = UIAlertAction(title: "Aceptar", style: .default, handler: self.okHandler2)
              alert.addAction(okAction)
              
              let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
               alert.addAction(cancelAction)
              // 4. Present the alert.
              self.present(alert, animated: true, completion: nil)

                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            
            let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.txtloop_ntiempo.text = self.txtloop_ntiempo.text
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(tie)
            sheet.addAction(cancelar)
            present(sheet,animated: true, completion: nil)
            
        }
        
        if indexPath.section == 2 && indexPath.row == 1 {

            txtbtn_looptiempouni.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Unidad de tiempo", message: nil, preferredStyle: .actionSheet)
            let seg=UIAlertAction(title: "Segundos", style: .default){
                (action) in self.txtbtn_looptiempouni.setTitle("Segundos", for: .normal)
                UserDefaults.standard.set("Segundos", forKey: self.perfilSeleccionado + "loop_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let min=UIAlertAction(title: "Minutos", style: .default){
                (action) in self.txtbtn_looptiempouni.setTitle("Minutos", for: .normal)
                UserDefaults.standard.set("Minutos", forKey: self.perfilSeleccionado + "loop_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let hs=UIAlertAction(title: "Horas", style: .default){
                (action) in self.txtbtn_looptiempouni.setTitle("Horas", for: .normal)
                UserDefaults.standard.set("Horas", forKey: self.perfilSeleccionado + "loop_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.txtbtn_looptiempouni.setTitle(self.txtbtn_looptiempouni.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(seg)
            sheet.addAction(min)
            sheet.addAction(hs)
            sheet.addAction(cancelar)
            present(sheet,animated: true, completion: nil)
            
        }
        if indexPath.section == 2 && indexPath.row == 2 {

                          loopUnidadDetenerse.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
                          let sheet = UIAlertController(title: "Detenerse", message: nil, preferredStyle: .actionSheet)
                          let nun=UIAlertAction(title: "Nunca", style: .default){
                              (action) in self.loopDetenerseOut.setTitle("Nunca", for: .normal)
                              UserDefaults.standard.set("Nunca", forKey: self.perfilSeleccionado + "loop_Detenerse")
                              if let index = self.tableView.indexPathForSelectedRow{
                              self.tableView.deselectRow(at: index, animated: true)
                              }
                          }
                          let tie=UIAlertAction(title: "Determinar tiempo", style: .default){
                              (action) in

                            self.cualTextfiled = 0
                            //1. Create the alert controller.
                            let alert = UIAlertController(title: "Ingrese tiempo en " + (self.loopUnidadDetenerse.title(for: .normal) ?? "Segundos").lowercased() , message: nil, preferredStyle: .alert)

                            //2. Add the text field. You can configure it however you need.
                            alert.addTextField(configurationHandler: self.alertTextFiled)

                            // 3. Grab the value from the text field, and print it when the user clicks OK.
                            let okAction = UIAlertAction(title: "Aceptar", style: .default, handler: self.okHandler)
                            alert.addAction(okAction)
                            
                            let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
                             alert.addAction(cancelAction)
                            // 4. Present the alert.
                            self.present(alert, animated: true, completion: nil)

                              if let index = self.tableView.indexPathForSelectedRow{
                              self.tableView.deselectRow(at: index, animated: true)
                              }
                          }
                          
                          let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                              (action) in self.loopUnidadDetenerse.setTitle(self.loopUnidadDetenerse.title(for: .normal), for: .normal)
                              if let index = self.tableView.indexPathForSelectedRow{
                              self.tableView.deselectRow(at: index, animated: true)
                              }
                          }
                          sheet.addAction(nun)
                          sheet.addAction(tie)
                          sheet.addAction(cancelar)
                          present(sheet,animated: true, completion: nil)
                          
                      }
        if indexPath.section == 2 && indexPath.row == 3 {

                   loopUnidadDetenerse.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
                   let sheet = UIAlertController(title: "Unidad de tiempo", message: nil, preferredStyle: .actionSheet)
                   let seg=UIAlertAction(title: "Segundos", style: .default){
                       (action) in self.loopUnidadDetenerse.setTitle("Segundos", for: .normal)
                       UserDefaults.standard.set("Segundos", forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse")
                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   let min=UIAlertAction(title: "Minutos", style: .default){
                       (action) in self.loopUnidadDetenerse.setTitle("Minutos", for: .normal)
                       UserDefaults.standard.set("Minutos", forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse")
                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   let hs=UIAlertAction(title: "Horas", style: .default){
                       (action) in self.loopUnidadDetenerse.setTitle("Horas", for: .normal)
                       UserDefaults.standard.set("Horas", forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse")
                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                       (action) in self.loopUnidadDetenerse.setTitle(self.loopUnidadDetenerse.title(for: .normal), for: .normal)
                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   sheet.addAction(seg)
                   sheet.addAction(min)
                   sheet.addAction(hs)
                   sheet.addAction(cancelar)
                   present(sheet,animated: true, completion: nil)
                   
               }
        
        
        if indexPath.section == 3 && indexPath.row == 0 {
            textbtn_timelapsestart.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Elije un lado", message: nil, preferredStyle: .actionSheet)
            let act_derecho=UIAlertAction(title: "Derecho", style: .default){
                (action) in self.textbtn_timelapsestart.setTitle("Derecho", for: .normal)
                UserDefaults.standard.set("Derecho", forKey: self.perfilSeleccionado + "timelapse_lado")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let act_izquierdo=UIAlertAction(title: "Izquierdo", style: .default){
                (action) in self.textbtn_timelapsestart.setTitle("Izquierdo", for: .normal)
                UserDefaults.standard.set("Izquierdo", forKey: self.perfilSeleccionado + "timelapse_lado")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let act_cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.textbtn_timelapsestart.setTitle(self.textbtn_timelapsestart.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(act_derecho)
            sheet.addAction(act_izquierdo)
            sheet.addAction(act_cancelar)
            present(sheet,animated: true, completion: nil)
            
        }
        
        if indexPath.section == 3 && indexPath.row == 1 {

                   txtbtn_tiempouni.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
                   let sheet = UIAlertController(title: "Duracion del Timelapse", message: nil, preferredStyle: .actionSheet)
                   
                   let tie=UIAlertAction(title: "Determinar tiempo", style: .default){
                       (action) in

                     self.cualTextfiled = 1
                     //1. Create the alert controller.
                     let alert = UIAlertController(title: "Ingrese tiempo en " + (self.txtbtn_tiempouni.title(for: .normal) ?? "Segundos").lowercased() , message: nil, preferredStyle: .alert)

                     //2. Add the text field. You can configure it however you need.
                     alert.addTextField(configurationHandler: self.alertTextFiled)

                     // 3. Grab the value from the text field, and print it when the user clicks OK.
                     let okAction = UIAlertAction(title: "Aceptar", style: .default, handler: self.okHandler3)
                     alert.addAction(okAction)
                     
                     let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
                      alert.addAction(cancelAction)
                     // 4. Present the alert.
                     self.present(alert, animated: true, completion: nil)

                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   
                   let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                       (action) in self.txtbox_tiempodur.text = self.txtbox_tiempodur.text
                       if let index = self.tableView.indexPathForSelectedRow{
                       self.tableView.deselectRow(at: index, animated: true)
                       }
                   }
                   sheet.addAction(tie)
                   sheet.addAction(cancelar)
                   present(sheet,animated: true, completion: nil)
                   
               }
        
        if indexPath.section == 3 && indexPath.row == 2 {

            txtbtn_tiempouni.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Unidad de tiempo", message: nil, preferredStyle: .actionSheet)
            let seg=UIAlertAction(title: "Segundos", style: .default){
                (action) in self.txtbtn_tiempouni.setTitle("Segundos", for: .normal)
                UserDefaults.standard.set("Segundos", forKey: self.perfilSeleccionado + "timelapse_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let min=UIAlertAction(title: "Minutos", style: .default){
                (action) in self.txtbtn_tiempouni.setTitle("Minutos", for: .normal)
                UserDefaults.standard.set("Minutos", forKey: self.perfilSeleccionado + "timelapse_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let hs=UIAlertAction(title: "Horas", style: .default){
                (action) in self.txtbtn_tiempouni.setTitle("Horas", for: .normal)
                UserDefaults.standard.set("Horas", forKey: self.perfilSeleccionado + "timelapse_unidadtiempo")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.txtbtn_tiempouni.setTitle(self.txtbtn_tiempouni.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(seg)
            sheet.addAction(min)
            sheet.addAction(hs)
            sheet.addAction(cancelar)
            present(sheet,animated: true, completion: nil)
        }
        
        if indexPath.section == 3 && indexPath.row == 3 {
            
            txtbtn_movcamara.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Movimiento de cámara", message: nil, preferredStyle: .actionSheet)
            let pes=UIAlertAction(title: "Punto específico", style: .default){
                (action) in self.txtbtn_movcamara.setTitle("Punto específico", for: .normal)
                UserDefaults.standard.set("Punto específico", forKey:self.perfilSeleccionado +  "timelapse_movimiento")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let man=UIAlertAction(title: "Manual", style: .default){
                (action) in self.txtbtn_movcamara.setTitle("Manual", for: .normal)
                UserDefaults.standard.set("Manual", forKey: self.perfilSeleccionado + "timelapse_movimiento")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let est=UIAlertAction(title: "Estático", style: .default){
                (action) in self.txtbtn_movcamara.setTitle("Estático", for: .normal)
                UserDefaults.standard.set("Estático", forKey: self.perfilSeleccionado + "timelapse_movimiento")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.txtbtn_movcamara.setTitle(self.txtbtn_movcamara.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(pes)
            sheet.addAction(man)
            sheet.addAction(est)
            sheet.addAction(cancelar)
            present(sheet,animated: true, completion: nil)
            
        }
        if indexPath.section == 4 && indexPath.row == 0 {
            txtbtn_ordencontroles.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Controles del Joystick", message: nil, preferredStyle: .actionSheet)
            let nor=UIAlertAction(title: "Normal", style: .default){
                (action) in self.txtbtn_ordencontroles.setTitle("Normal", for: .normal)
                UserDefaults.standard.set("Normal", forKey: self.perfilSeleccionado + "joystick_orden")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let inv=UIAlertAction(title: "Invertido", style: .default){
                (action) in self.txtbtn_ordencontroles.setTitle("Invertido", for: .normal)
                UserDefaults.standard.set("Invertido", forKey: self.perfilSeleccionado + "joystick_orden")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.txtbtn_ordencontroles.setTitle(self.txtbtn_ordencontroles.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(nor)
            sheet.addAction(inv)
            sheet.addAction(cancelar)
            present(sheet,animated: true, completion: nil)
            
        }
        
        
        if indexPath.section == 4 && indexPath.row == 1 {
            outbtn_joystickdesde.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
            let sheet = UIAlertController(title: "Elije un control", message: nil, preferredStyle: .actionSheet)
            let app=UIAlertAction(title: "App", style: .default){
                (action) in self.outbtn_joystickdesde.setTitle("App", for: .normal)
                UserDefaults.standard.set("App", forKey: self.perfilSeleccionado + "joystick_desde")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let remote=UIAlertAction(title: "Remote", style: .default){
                (action) in self.outbtn_joystickdesde.setTitle("Remote", for: .normal)
                UserDefaults.standard.set("Remote", forKey: self.perfilSeleccionado + "joystick_desde")
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            let act_cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in self.outbtn_joystickdesde.setTitle(self.outbtn_joystickdesde.title(for: .normal), for: .normal)
                if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
                }
            }
            sheet.addAction(app)
            sheet.addAction(remote)
            sheet.addAction(act_cancelar)
            present(sheet,animated: true, completion: nil)
        }
    }
    
    @IBAction func btn_conexiontimeout(_ sender: Any) {
      
        
    }
    @IBOutlet weak var txtbox_tiempodur: UITextField!
    
    @IBOutlet weak var txtbtn_movcamara: UIButton!
    
    override func viewDidAppear(_ animated: Bool) {
        let shortcutScan = UserDefaults.standard.integer(forKey: "shortcutScan")
        
        if(!serial.isReady){
            if( shortcutScan == 1){
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let newViewController = storyBoard.instantiateViewController(withIdentifier: "scanBluetooth") as! ScannerViewController
                
                self.navigationController?.pushViewController(newViewController, animated: true)
                        
                UserDefaults.standard.set(0, forKey: "shortcutScan")
            }
        }
        
        
        reloadView()
        SettingsTimer?.invalidate()
        SettingsTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
         let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
                     self.lblperfilSeleccionado.text = perfilActual
                     perfilSeleccionado = perfilActual
        let timeout_saved = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timeout") ?? "Nunca"
        self.txtbtn_conexiontimeout.setTitle(timeout_saved, for: .normal)
        
        let joystick_orden = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_orden") ?? "Normal"
        self.txtbtn_ordencontroles.setTitle(joystick_orden, for: .normal)
        
        let timelapse_mov = UserDefaults.standard.string(forKey: self.perfilSeleccionado +  "timelapse_movimiento") ?? "Punto específico"
        self.txtbtn_movcamara.setTitle(timelapse_mov, for: .normal)
        
        let timelapse_utmp = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_unidadtiempo") ?? "Segundos"
        self.txtbtn_tiempouni.setTitle(timelapse_utmp, for: .normal)
        
        let timelapse_lado = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_lado") ?? "Derecho"
        self.textbtn_timelapsestart.setTitle(timelapse_lado, for: .normal)
        
        let timelapse_time = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_time") ?? "60"
               self.txtbox_tiempodur.text = timelapse_time
        
        let joystick_desde = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_desde") ?? "App"
                      self.outbtn_joystickdesde.setTitle(joystick_desde, for: .normal)
        
        let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
        self.txtloop_ntiempo.text = loop_delaytime
        
        let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
        self.txtbtn_looptiempouni.setTitle(loop_unidadtiempo, for: .normal)
        
        let loop_unidadtiempoDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse") ?? "Segundos"
        self.loopUnidadDetenerse.setTitle(loop_unidadtiempoDetenerse, for: .normal)
        
        let loop_Detenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_Detenerse") ?? "Nunca"
               self.loopDetenerseOut.setTitle(loop_Detenerse, for: .normal)
    }
    
    var cualTextfiled = 0
    
   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let textFieldText = textField.text,
            let rangeOfTextToReplace = Range(range, in: textFieldText) else {
                return false
        }
        let substringToReplace = textFieldText[rangeOfTextToReplace]
        let count = textFieldText.count - substringToReplace.count + string.count
        
        if(cualTextfiled == 0){
            return count <= 2
        }
        else{
            return count <= 3
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField == txtloop_ntiempo) {
            cualTextfiled = 0
        }
        else if(textField == txtbox_tiempodur){
            cualTextfiled = 1
        }
    }
    
    @IBOutlet weak var buttonDisconection: UIButton!
    @IBOutlet weak var lblestadoActual: UILabel!
    @IBOutlet weak var buttonConection: UIButton!
    @IBOutlet weak var lblConexion: UILabel!
    @IBAction func disconectAction(_ sender: Any) {
        serial.disconnect()
        reloadView()
    }
    @IBOutlet weak var celdaConexion: UITableViewCell!
    @objc func reloadView() {
        // in case we're the visible view again
        serial.delegate = self
        
        if serial.isReady {
            lblConexion.text = "Conexión: " + (serial.connectedPeripheral!.name ?? " ")
            lblestadoActual.text = "Estado actual: Conectado"
            buttonConection.isHidden = true
            buttonDisconection.isHidden = false
            buttonConection.isUserInteractionEnabled = true
            celdaConexion.isUserInteractionEnabled = true
            buttonConection.isEnabled = true
        } else if serial.centralManager.state == .poweredOn {
            lblestadoActual.text = "Estado actual: Desconectado"
            lblConexion.text = "Establecer conexión"
            buttonConection.isHidden = false
            buttonDisconection.isHidden = true
            buttonConection.isUserInteractionEnabled = true
            buttonConection.isEnabled = true
            celdaConexion.isUserInteractionEnabled = true
        } else {
            lblestadoActual.text = "Estado actual: Desconectado"
            lblConexion.text = "Establecer conexión"
            buttonConection.isHidden = false
            buttonDisconection.isHidden = true
            buttonConection.isUserInteractionEnabled = false
            buttonConection.isEnabled = false
            celdaConexion.isUserInteractionEnabled = false
        }
    }
    @objc func runTimedCode(){
        updateSettings()
    }
    
    override func viewDidLoad() {
        
        super.loadView()
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        
        txtloop_ntiempo.smartInsertDeleteType = UITextSmartInsertDeleteType.no
        txtloop_ntiempo.delegate = self
        txtbox_tiempodur.smartInsertDeleteType = UITextSmartInsertDeleteType.no
        txtbox_tiempodur.delegate = self
        
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
              self.lblperfilSeleccionado.text = perfilActual
              perfilSeleccionado = perfilActual
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.doneClicked))
        toolBar.setItems([doneButton], animated: false)
        
        txtbox_tiempodur.inputAccessoryView = toolBar
        txtloop_ntiempo.inputAccessoryView = toolBar
        
        updateSettings()
    }
    
    func updateSettings(){
        
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
        self.lblperfilSeleccionado.text = perfilActual
        
        perfilSeleccionado = perfilActual
        let timeout_saved = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timeout") ?? "Nunca"
        self.txtbtn_conexiontimeout.setTitle(timeout_saved, for: .normal)
        
        let joystick_orden = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_orden") ?? "Normal"
        self.txtbtn_ordencontroles.setTitle(joystick_orden, for: .normal)
        
        let timelapse_mov = UserDefaults.standard.string(forKey: self.perfilSeleccionado +  "timelapse_movimiento") ?? "Punto específico"
        self.txtbtn_movcamara.setTitle(timelapse_mov, for: .normal)
        
        let timelapse_utmp = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_unidadtiempo") ?? "Segundos"
        self.txtbtn_tiempouni.setTitle(timelapse_utmp, for: .normal)
        
        let timelapse_lado = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_lado") ?? "Derecho"
        self.textbtn_timelapsestart.setTitle(timelapse_lado, for: .normal)
        
        let timelapse_time = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_time") ?? "60"
               self.txtbox_tiempodur.text = timelapse_time
        
        let joystick_desde = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "joystick_desde") ?? "App"
                      self.outbtn_joystickdesde.setTitle(joystick_desde, for: .normal)
        
        let loop_delaytime = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_delaytime") ?? "0"
        self.txtloop_ntiempo.text = loop_delaytime
        
        let loop_unidadtiempo = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempo") ?? "Segundos"
        self.txtbtn_looptiempouni.setTitle(loop_unidadtiempo, for: .normal)
        
        let loop_unidadtiempoDetenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_unidadtiempoDetenerse") ?? "Segundos"
         self.loopUnidadDetenerse.setTitle(loop_unidadtiempoDetenerse, for: .normal)
         
         let loop_Detenerse = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "loop_Detenerse") ?? "Nunca"
                self.loopDetenerseOut.setTitle(loop_Detenerse, for: .normal)
    }
    
    @IBOutlet weak var lblperfilSeleccionado: UILabel!
    @IBOutlet weak var txtloop_ntiempo: UITextField!
    @IBAction func loop_ntiempo(_ sender: UITextField) {
         let time: String = txtloop_ntiempo.text ?? "0"
         
        UserDefaults.standard.set(time, forKey: self.perfilSeleccionado + "loop_delaytime")
    }
    @IBOutlet weak var txtbtn_tiempouni: UIButton!
    @IBAction func timelapse_ntiempo(_ sender: UITextField) {
        
        let time: String = txtbox_tiempodur.text ?? "60"
        
       UserDefaults.standard.set(time, forKey: self.perfilSeleccionado + "timelapse_time")
        
    }
    @objc func doneClicked(){
         view.endEditing(true)
     }
    
    @IBOutlet weak var txtbtn_looptiempouni: UIButton!
    @IBAction func btn_looptiempouni(_ sender: Any) {
    }
    @IBAction func btn_tiempouni(_ sender: Any) {
    }
    
    @IBAction func btn_movcamara(_ sender: Any) {
    }
    @IBOutlet weak var txtbtn_ordencontroles: UIButton!
    @IBAction func btn_ordencontroles(_ sender: Any) {
        
    }
    
    
    func alertTextFiled(textField: UITextField){
        alertTextFiled=textField
        alertTextFiled?.placeholder="Tiempo"
        alertTextFiled?.keyboardType = UIKeyboardType.numberPad
        alertTextFiled?.smartInsertDeleteType = UITextSmartInsertDeleteType.no
        alertTextFiled?.delegate = self
        
    }
    func okHandler(alert: UIAlertAction!)
    {
        let textField = self.alertTextFiled // Force unwrapping because we know it exists.
        
        self.loopDetenerseOut.setTitle(textField?.text, for: .normal)
        UserDefaults.standard.set(textField?.text, forKey: self.perfilSeleccionado + "loop_Detenerse")
    }
    
    func okHandler2(alert: UIAlertAction!)
    {
        let textField = self.alertTextFiled // Force unwrapping because we know it exists.
        
        self.txtloop_ntiempo.text = textField?.text
         
        UserDefaults.standard.set(textField?.text, forKey: self.perfilSeleccionado + "loop_delaytime")
    }
    
    func okHandler3(alert: UIAlertAction!)
       {
           let textField = self.alertTextFiled // Force unwrapping because we know it exists.
           
           self.txtbox_tiempodur.text = textField?.text
           UserDefaults.standard.set(textField?.text, forKey: self.perfilSeleccionado + "timelapse_time")
       }
    
    
}
