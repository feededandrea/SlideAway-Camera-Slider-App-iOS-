//
//  SceneDelegate.swift
//  SliderCamera
//
//  Created by Feede on 10/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    var lastTabIndex: Int?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        // Use this method to optionally configure and attach the UIWindow `window` to the provided UIWindowScene `scene`.
        // If using a storyboard, the `window` property will automatically be initialized and attached to the scene.
        // This delegate does not imply the connecting scene or session are new (see `application:configurationForConnectingSceneSession` instead).
        guard let _ = (scene as? UIWindowScene) else { return }
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not neccessarily discarded (see `application:didDiscardSceneSessions` instead).
    }
    func windowScene(_ windowScene: UIWindowScene, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
           // When the user opens the app through a quick action, this is now the method that will be called
           (UIApplication.shared.delegate as! AppDelegate).shortcutItemToProcess = shortcutItem
       }
    func sceneDidBecomeActive(_ scene: UIScene) {
        // Is there a shortcut item that has not yet been processed?
        if let shortcutItem = (UIApplication.shared.delegate as! AppDelegate).shortcutItemToProcess {
            // In this sample an alert is being shown to indicate that the action has been triggered,
            // but in real code the functionality for the quick action would be triggered.
            
            var perfilesAnteriores = [String](arrayLiteral: "","")
            let perfilesAntes = UserDefaults.standard.stringArray(forKey: "perfilesAnteriores")
            perfilesAnteriores = perfilesAntes ?? [String](arrayLiteral: "","")
            
            if shortcutItem.type == "slider.app.SliderCamera.profile1"
            {
                UserDefaults.standard.set(perfilesAnteriores[0], forKey: "perfilActual")
                 if let tabVC = self.window?.rootViewController as? UITabBarController {
                    if(lastTabIndex == 0){
                        tabVC.selectedIndex = 1
                        tabVC.selectedIndex = 0
                    }
                    else if(lastTabIndex == 1){
                        tabVC.selectedIndex = 0
                        tabVC.selectedIndex = 1
                    }
                    else if(lastTabIndex == 2){
                        tabVC.selectedIndex = 1
                        tabVC.selectedIndex = 2
                    }
                }
                print("profile1")
            }
            
            if shortcutItem.type == "slider.app.SliderCamera.profile2"
            {
                UserDefaults.standard.set(perfilesAnteriores[1], forKey: "perfilActual")
                if let tabVC = self.window?.rootViewController as? UITabBarController {
                    if(lastTabIndex == 0){
                        tabVC.selectedIndex = 1
                        tabVC.selectedIndex = 0
                    }
                    else if(lastTabIndex == 1){
                        tabVC.selectedIndex = 0
                        tabVC.selectedIndex = 1
                    }
                    else if(lastTabIndex == 2){
                        tabVC.selectedIndex = 1
                        tabVC.selectedIndex = 2
                    }
                }
                print("profile2")
            }
            
            if shortcutItem.type == "slider.app.SliderCamera.scan"
                       {
                          UserDefaults.standard.set(1, forKey: "shortcutScan")
                        if let tabVC = self.window?.rootViewController as? UITabBarController {
                            tabVC.selectedIndex = 1
                            tabVC.selectedIndex = 2
                        }
            }
            if shortcutItem.type == "slider.app.SliderCamera.timelapse"
                         {
                            UserDefaults.standard.set(1, forKey: "shortcutTimelapse")
                          if let tabVC = self.window?.rootViewController as? UITabBarController {
                              tabVC.selectedIndex = 2
                              tabVC.selectedIndex = 1
                          }
              }
            // Reset the shorcut item so it's never processed twice.
            (UIApplication.shared.delegate as! AppDelegate).shortcutItemToProcess = nil
        }
    }
    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene will move from an active state to an inactive state.
        // This may occur due to temporary interruptions (ex. an incoming phone call).
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from the background to the foreground.
        // Use this method to undo the changes made on entering the background.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        
        if let tabVC = self.window?.rootViewController as? UITabBarController {
            lastTabIndex = tabVC.selectedIndex
            
        }
        UserDefaults.standard.set(0, forKey: "shortcutScan")
        UserDefaults.standard.set(0, forKey: "shortcutTimelapse")
        // Called as the scene transitions from the foreground to the background.
        // Use this method to save data, release shared resources, and store enough scene-specific state information
        // to restore the scene back to its current state.

    }

}
