//
//  TimelapseScreen.swift
//  SliderCamera
//
//  Created by Feede on 24/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import UserNotifications
var TlTimer: Timer?
var time: Int = 0

var segUniversales: Double = 0
class TimelapseScreen: UITableViewController{
    
    var perfilSeleccionado: String! = "Default"
       
       override func viewDidLoad() {
         perfilSeleccionado = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
        
        cargarDatos()
        
        
       }
    @IBOutlet weak var lado: UILabel!
    @IBOutlet weak var duracion: UILabel!
    @IBOutlet weak var modo: UILabel!
    @IBOutlet weak var rueditaCargando: UIActivityIndicatorView!
    
    override func viewDidAppear(_ animated: Bool) {
        
        cargarDatos()
             
               
    }
    func cargarDatos(){
        
        let tlEstado = UserDefaults.standard.string(forKey: "tlEstado") ?? "Sin comenzar"
        
        let notiEnabled = UserDefaults.standard.string(forKey: "notiEnabled") ?? "false0"
        if(notiEnabled=="false0"){
            notificacionCell.isUserInteractionEnabled = false
            notificacionlblCell.textColor = UIColor.gray
            notificacionCell.accessoryType = .none
        }
        else if(notiEnabled=="true"){
            notificacionCell.isUserInteractionEnabled = true
            notificacionlblCell.textColor = UIColor.link
            notificacionCell.accessoryType = .none
        }
        else if(notiEnabled=="false1"){
            notificacionCell.isUserInteractionEnabled = false
            notificacionlblCell.textColor = UIColor.gray
            notificacionCell.accessoryType = .checkmark
        }
        
        let timelapse_mov = UserDefaults.standard.string(forKey: self.perfilSeleccionado +  "timelapse_movimiento") ?? "Punto específico"
             
             modo.text = timelapse_mov
        let timelapse_utmp = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_unidadtiempo") ?? "Segundos"
                 
                    
        let timelapse_lado = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_lado") ?? "Derecho"
             lado.text = timelapse_lado
                    
        let timelapse_time = UserDefaults.standard.string(forKey: self.perfilSeleccionado + "timelapse_time") ?? "60"
             duracion.text = timelapse_time + " " + timelapse_utmp
        
        if(tlEstado=="Sin comenzar"){
                   lblTiempoRestante.text = "Faltan: "
                   rueditaCargando.isHidden=true
                   rueditaCargando.stopAnimating()
                   comenzarCell.isUserInteractionEnabled = true
                   comenzarLbl.setTitleColor( UIColor.link, for: .normal)
                   finalizarCell.isUserInteractionEnabled = false
                   finalizarLbl.setTitleColor( UIColor.gray, for: .normal)
                   iconPlay.tintColor = UIColor.link
                   iconStop.tintColor = UIColor.gray
                   
                   if(timelapse_utmp=="Segundos"){
                       let i: Int = Int(timelapse_time) ?? 0
                       UserDefaults.standard.set(i, forKey: "tlTiempo")
                   }
                   else if(timelapse_utmp=="Minutos"){
                       var i2: Int = Int(timelapse_time) ?? 0
                       i2 = i2 * 60
                       UserDefaults.standard.set(i2, forKey: "tlTiempo")
                   }
                   else if(timelapse_utmp=="Horas"){
                       var i3: Int = Int(timelapse_time) ?? 0
                       i3 = i3 * 60
                       i3 = i3 * 60
                       UserDefaults.standard.set(i3, forKey: "tlTiempo")
                   }
                   

               }
               else if(tlEstado=="En proceso"){
            
                if let date3 = UserDefaults.standard.object(forKey: "tlSettedTime") as? Date {
                       let elapsedTime = date3.timeIntervalSince(Date())
                       let tiempito = UserDefaults.standard.integer(forKey: "tlTiempo")
                       let val = floor(Double(tiempito+1)-elapsedTime)
                       let f = Float(val/Double(tiempito))
                progressBar.setProgress(f, animated: false)
                    
            }
            
                   actualizarTiempo()
                   TlTimer?.invalidate()
            TlTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
                   time = UserDefaults.standard.integer(forKey: "tlTiempo")
                   rueditaCargando.isHidden=false
                   rueditaCargando.startAnimating()
                   comenzarCell.isUserInteractionEnabled = false
                   comenzarLbl.setTitleColor( UIColor.gray, for: .normal)
                   finalizarCell.isUserInteractionEnabled = true
                   finalizarLbl.setTitleColor( UIColor.systemRed, for: .normal)
                   iconPlay.tintColor = UIColor.gray
                   iconStop.tintColor = UIColor.systemRed
               }
               else if(tlEstado=="Finalizado"){
                   lblTiempoRestante.text = "Finalizado"
                   UserDefaults.standard.set("Sin comenzar", forKey: "tlEstado")
                   rueditaCargando.isHidden=true
                   rueditaCargando.stopAnimating()
                   comenzarCell.isUserInteractionEnabled = true
                   comenzarLbl.setTitleColor( UIColor.link, for: .normal)
                   finalizarCell.isUserInteractionEnabled = false
                   finalizarLbl.setTitleColor( UIColor.gray, for: .normal)
                   iconPlay.tintColor = UIColor.link
                   iconStop.tintColor = UIColor.gray
               }
        
    }
    
    func actualizarTiempo(){
        
        lblTiempoRestante.text = "Faltan: "
        
                        
        if let date3 = UserDefaults.standard.object(forKey: "tlSettedTime") as? Date {
            let elapsedTime = date3.timeIntervalSince(Date())
            segUniversales = elapsedTime
            // convert from seconds to hours, rounding down to the nearest hour
            let hs = floor(elapsedTime / 60 / 60)
            let min = floor((elapsedTime - (hs * 60 * 60)) / 60)
            let seg = floor((elapsedTime - (hs * 60 * 60) - min * 60))
            
            
            let tiempito = UserDefaults.standard.integer(forKey: "tlTiempo")
            let val = floor(Double(tiempito+1)-elapsedTime)
            let f = Float(val/Double(tiempito))
            progressBar.setProgress(f, animated: true)
            
            if(hs == 1){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(hs)) hora"
            }
            else if(hs != 0){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(hs)) horas"
            }
            if((min == 1)&&(hs != 0)){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + ", \(Int(min)) minuto y "
            }
            else if((min != 0)&&(hs != 0)){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + ", \(Int(min)) minutos y "
            }
            else if((min == 1)&&(hs == 0)){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(min)) minuto y "
            }
            else if((min != 0)&&(hs == 0)){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(min)) minutos y "
            }
            
            if(seg == 1){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(seg)) segundo"
            }
            else if(seg != 0){
                lblTiempoRestante.text = (lblTiempoRestante.text ?? "Faltan: ") + "\(Int(seg)) segundos"
            }
            
            if((hs==0 && min==0 && seg==0) || (hs<0)){
                progressBar.setProgress(1.0, animated: true)
                UserDefaults.standard.set("false0", forKey: "notiEnabled")
                notificacionCell.isUserInteractionEnabled = false
                notificacionlblCell.textColor = UIColor.gray
                lblTiempoRestante.text = "Finalizado"
                rueditaCargando.isHidden=true
                TlTimer?.invalidate()
                iconPlay.tintColor = UIColor.link
                iconStop.tintColor = UIColor.gray
                rueditaCargando.stopAnimating()
                comenzarCell.isUserInteractionEnabled = true
                comenzarLbl.setTitleColor( UIColor.link, for: .normal)
                finalizarCell.isUserInteractionEnabled = false
                finalizarLbl.setTitleColor( UIColor.gray, for: .normal)
                UserDefaults.standard.set("Finalizado", forKey: "tlEstado")
            }
            //print("\(Int(hs)) hr and \(Int(min)) min and \(Int(seg)) sec")
           // lblTiempoRestante.text = "Faltan: \(Int(hs)) hr and \(Int(min)) min and \(Int(seg)) sec"
        }
        
    }
    
    @IBOutlet weak var comenzarCell: UITableViewCell!
    @IBOutlet weak var finalizarCell: UITableViewCell!
    @IBOutlet weak var comenzarLbl: UIButton!
    @IBOutlet weak var finalizarLbl: UIButton!
    @IBOutlet weak var notificacionCell: UITableViewCell!
    @IBOutlet weak var notificacionlblCell: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 && indexPath.row == 2 { //Notificarme cuando termine
            notificacionCell.isUserInteractionEnabled = false
            notificacionlblCell.textColor = UIColor.gray
            UserDefaults.standard.set("false1", forKey: "notiEnabled")
            if let cell = tableView.cellForRow(at: indexPath) {
                  cell.accessoryType = .checkmark

            }
            let center = UNUserNotificationCenter.current()
            
            center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
                
            }
            
            let contenct = UNMutableNotificationContent()
            contenct.title = "Timelapse"
            contenct.body = "El timelapse ya ha finalizado"
            let date = Date().addingTimeInterval(segUniversales)
            
            let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
            
            let uuidString = UUID().uuidString
            let request = UNNotificationRequest(identifier: uuidString, content: contenct, trigger: trigger)
            
            center.add(request) { (error) in
                //Error chequeo
            }
            if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
            }
        }
        
        
        
        
        if indexPath.section == 2 && indexPath.row == 0 { // Comenzar
            cargarDatos()
            notificacionCell.isUserInteractionEnabled = true
            notificacionlblCell.textColor = UIColor.link
            UserDefaults.standard.set("true", forKey: "notiEnabled")
           
            
            TlTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
            time = UserDefaults.standard.integer(forKey: "tlTiempo")
            rueditaCargando.isHidden=false
            rueditaCargando.startAnimating()
            comenzarCell.isUserInteractionEnabled = false
            comenzarLbl.setTitleColor( UIColor.gray, for: .normal)
            finalizarCell.isUserInteractionEnabled = true
            iconPlay.tintColor = UIColor.gray
            iconStop.tintColor = UIColor.systemRed
            finalizarLbl.setTitleColor( UIColor.systemRed, for: .normal)
            UserDefaults.standard.set("En proceso", forKey: "tlEstado")
            
            let date = Date()
            let tlTiempo = UserDefaults.standard.integer(forKey: "tlTiempo")
            var date2 = date
            date2.addTimeInterval(TimeInterval(tlTiempo))
            UserDefaults.standard.set(date2, forKey: "tlSettedTime")
            if let index = self.tableView.indexPathForSelectedRow{
                self.tableView.deselectRow(at: index, animated: true)
            }
        }
        if indexPath.section == 2 && indexPath.row == 1 { //Finalizar

            finalizarLbl.setTitleColor( UIColor.gray, for: .normal)
            //1. Create the alert controller.
                      let alert = UIAlertController(title: "¿Está seguro que desea interrimpir el Timelapse?", message: nil, preferredStyle: .alert)

                      //2. Add the text field. You can configure it however you need.

                      // 3. Grab the value from the text field, and print it when the user clicks OK.
                      let okAction = UIAlertAction(title: "Finalizar", style: .destructive, handler: self.okHandler)
                      alert.addAction(okAction)
                      
                      let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: self.cancelHandler)
                       alert.addAction(cancelAction)
                      // 4. Present the alert.
                      self.present(alert, animated: true, completion: nil)

            

        }
    }
    @IBOutlet weak var iconPlay: UIImageView!
    @IBOutlet weak var iconStop: UIImageView!
    
    @IBOutlet weak var lblTiempoRestante: UILabel!
    /*  override func viewWillDisappear(_ animated: Bool) {
        TlTimer?.invalidate()
    }*/
    @objc func runTimedCode(){
        print(String(time))
        actualizarTiempo()
    }
    
    func okHandler(alert: UIAlertAction!)
       {
           progressBar.setProgress(0.0, animated: true)
           lblTiempoRestante.text = "Finalizado"
           UserDefaults.standard.set("false0", forKey: "notiEnabled")
           notificacionCell.isUserInteractionEnabled = false
           notificacionCell.accessoryType = .none
           notificacionlblCell.textColor = UIColor.gray
           rueditaCargando.isHidden=true
           TlTimer?.invalidate()
           rueditaCargando.stopAnimating()
           comenzarCell.isUserInteractionEnabled = true
           comenzarLbl.setTitleColor( UIColor.link, for: .normal)
           finalizarCell.isUserInteractionEnabled = false
           iconPlay.tintColor = UIColor.link
           iconStop.tintColor = UIColor.gray
           finalizarLbl.setTitleColor( UIColor.gray, for: .normal)
           UserDefaults.standard.set("Finalizado", forKey: "tlEstado")
           if let index = self.tableView.indexPathForSelectedRow{
               self.tableView.deselectRow(at: index, animated: true)
           }
       }
       func cancelHandler(alert: UIAlertAction!)
          {
              finalizarLbl.setTitleColor( UIColor.systemRed, for: .normal)
              if let index = self.tableView.indexPathForSelectedRow{
                  self.tableView.deselectRow(at: index, animated: true)
              }
          }
}
