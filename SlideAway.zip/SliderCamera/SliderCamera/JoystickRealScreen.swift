//
//  JoystickRealScreen.swift
//  SliderCamera
//
//  Created by Feede on 24/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth



var t1 = String(format: "%03d", 128)
var t2 = String(format: "%03d", 128)
var t3 = String(format: "%03d", 128)
var numberX = Int(t1) ?? 128
var numberXs = Int(t3) ?? 128
var numberY = Int(t2) ?? 128
var string = String(format: "%03d", numberXs)
var string1 = String(format: "%03d", numberX)
var string2 = String(format: "%03d", numberY)

var GTimer: Timer?

class JoystickRealScreen: UIViewController, BluetoothSerialDelegate {
    
    
    
    func serialDidChangeState() {
        
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        statusConexion2.text = "Desconectado"
        statusConexion2.textColor = UIColor.label
        iconStatus.image = UIImage(systemName: "xmark.circle.fill")
        iconStatus.tintColor = UIColor.label
        statusConexion.text = "Conectadooooooooo"
        statusConexion.sizeToFit()
    }
    
    
    @IBOutlet weak var serialSend: UILabel!
    
    
    class func setJoystick( joystickX: String! = "", joystickY: String! = "") -> Void {
        t1 = joystickX
        t2 = joystickY
    }
    
   class func setJoystickOnlyX( joystickXOnlyX: String! = "") -> Void {
        t3 = joystickXOnlyX
        
    }
    @IBOutlet weak var iconStatus: UIImageView!
    override func viewDidAppear(_ animated: Bool) {
        
        if(serial.isReady){
            statusConexion2.text = "Conectado"
            statusConexion2.textColor = UIColor.systemGreen
            iconStatus.image = UIImage(systemName: "checkmark.circle.fill")
            iconStatus.tintColor = UIColor.systemGreen
            statusConexion.text = "Conectadoooooo"
            statusConexion.sizeToFit()
        }
        else{
            statusConexion2.text = "Desconectado"
            statusConexion2.textColor = UIColor.label
            iconStatus.image = UIImage(systemName: "xmark.circle.fill")
            iconStatus.tintColor = UIColor.label
            statusConexion.text = "Conectadooooooooo"
            statusConexion.sizeToFit()
        }
        GTimer = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
        updateShortcuts()
    }
    override func viewDidLoad() {
        // init serial
        serial = BluetoothSerial(delegate: self)
        updateShortcuts()
        statusConexion.layer.masksToBounds = true
        statusConexion.layer.cornerRadius = 15
        statusConexion2.layer.masksToBounds = true
        statusConexion2.layer.cornerRadius = 15
        }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    override func viewWillDisappear(_ animated: Bool) {
        GTimer?.invalidate()
    }
    @IBOutlet weak var statusConexion2: UILabel!
    @IBOutlet weak var statusConexion: UILabel!
    @objc func runTimedCode(){
        
        if(serial.isReady){
                   statusConexion2.text = "Conectado"
                   statusConexion2.textColor = UIColor.systemGreen
                   iconStatus.image = UIImage(systemName: "checkmark.circle.fill")
                   iconStatus.tintColor = UIColor.systemGreen
                   statusConexion.text = "Conectadoooooo"
                   statusConexion.sizeToFit()
               }
               else{
                   statusConexion2.text = "Desconectado"
                   statusConexion2.textColor = UIColor.label
                   iconStatus.image = UIImage(systemName: "xmark.circle.fill")
                   iconStatus.tintColor = UIColor.label
                   statusConexion.text = "Conectadooooooooo"
                   statusConexion.sizeToFit()
               }
        
        setText()
        setTextX()
        print("$" + "S" + string + "T" + string2 + "P" + string1 + "e!")
        serialSend.text = "$" + "S" + string + "T" + string2 + "P" + string1 + "e!"
        if serial.isReady {
            serial.sendMessageToDevice("$" + "S" + string + "T" + string2 + "P" + string1 + "e!") }
    }
    func setText(){
        numberXs = Int(t3) ?? 128
        numberX = Int(t1) ?? 128
        string1 = String(format: "%03d", numberX) // returns "100"
        numberY = Int(t2) ?? 128
        string2 = String(format: "%03d", numberY) // returns "100"
        
        if((numberX != 128) || (numberY != 128) || (numberXs != 128)){
            print("ola")
            if let items = tabBarController?.tabBar.items {
                  items[1].isEnabled = false
                  items[2].isEnabled = false
            }
        }
        else {
            if let items = tabBarController?.tabBar.items {
                  items[1].isEnabled = true
                  items[2].isEnabled = true
            }
        }
        
    }
    func setTextX(){
        numberXs = Int(t3) ?? 128
        numberY = Int(t2) ?? 128
        numberX = Int(t1) ?? 128
        string = String(format: "%03d", numberXs) // returns "100"
        
        if((numberX != 128) || (numberY != 128) || (numberXs != 128)){
        print("ola")
        if let items = tabBarController?.tabBar.items {
                items[1].isEnabled = false
                items[2].isEnabled = false
            }
        }
        else {
            if let items = tabBarController?.tabBar.items {
                items[1].isEnabled = true
                items[2].isEnabled = true
            }
        }
    }
    
    func updateShortcuts(){
        var perfilesAnteriores = [String](arrayLiteral: "","")
        let perfilesAntes = UserDefaults.standard.stringArray(forKey: "perfilesAnteriores")
        perfilesAnteriores = perfilesAntes ?? [String](arrayLiteral: "","")
        
        
        let subtitleTimelapse = UserDefaults.standard.string(forKey: "subtitleTimlepaseShortcut") ?? "60 segundos, lado: derecho"
        
        let timelaspeIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIcon.IconType.captureVideo)
        
        let timelapseItem = UIMutableApplicationShortcutItem(type: "slider.app.SliderCamera.timelapse", localizedTitle: "Iniciar Timelapse", localizedSubtitle: subtitleTimelapse, icon: timelaspeIcon, userInfo: nil)
        
        let profileIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIcon.IconType.favorite)
        
        var secondProfile = UIMutableApplicationShortcutItem(type: "slider.app.SliderCamera.profile2", localizedTitle: "", localizedSubtitle: nil, icon: profileIcon, userInfo: nil)
        
        var firstProfile = UIMutableApplicationShortcutItem(type: "slider.app.SliderCamera.profile1", localizedTitle: "", localizedSubtitle: nil, icon: profileIcon, userInfo: nil)
        
        if(perfilesAnteriores[0] != ""){
            firstProfile = UIMutableApplicationShortcutItem(type: "slider.app.SliderCamera.profile1", localizedTitle:perfilesAnteriores[0] , localizedSubtitle: "Establecer perfil", icon: profileIcon, userInfo: nil)
        }
        if(perfilesAnteriores[1] != ""){
            secondProfile = UIMutableApplicationShortcutItem(type: "slider.app.SliderCamera.profile2", localizedTitle: perfilesAnteriores[1], localizedSubtitle: "Establecer perfil", icon: profileIcon, userInfo: nil)
        }
        if((perfilesAnteriores[1] != "")&&(perfilesAnteriores[0] != "")){
            UIApplication.shared.shortcutItems = [timelapseItem, firstProfile, secondProfile]
        }
        else if((perfilesAnteriores[1] == "")&&(perfilesAnteriores[0] != "")){
            UIApplication.shared.shortcutItems = [timelapseItem, secondProfile]
        }
        else if((perfilesAnteriores[1] != "")&&(perfilesAnteriores[0] == "")){
            UIApplication.shared.shortcutItems = [timelapseItem, firstProfile]
        }
        else if((perfilesAnteriores[1] == "")&&(perfilesAnteriores[0] == "")){
            UIApplication.shared.shortcutItems = [timelapseItem]
        }

    }

}
