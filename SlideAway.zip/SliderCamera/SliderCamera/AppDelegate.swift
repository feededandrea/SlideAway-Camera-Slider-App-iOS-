//
//  AppDelegate.swift
//  SliderCamera
//
//  Created by Feede on 10/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var shortcutItemToProcess: UIApplicationShortcutItem?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        return true
    }
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.

        // Grab a reference to the shortcutItem to use in the scene
        if let shortcutItem = options.shortcutItem {
            shortcutItemToProcess = shortcutItem
        }
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
   func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
          //let handledShortCutItem = handleShortCutItem(shortcutItem: shortcutItem)
          //completionHandler(handledShortCutItem)
      }
    

    /*
    func application(_ application: UIApplication, performActionForShorcutItem shortcutItem: UIApplicationShortcutItem, completionHandler: (Bool) -> Void) {

        print("shortcut activado")
        
    }*/


}

