//
//  PerfilScreen.swift
//  SliderCamera
//
//  Created by Feede on 21/10/2019.
//  Copyright © 2019 Feede. All rights reserved.
//

import Foundation
import UIKit

class PerfilScreen: UITableViewController {
    
    var perfiles = [String]()
    var perfilesAnteriores = [String](arrayLiteral: "","")
    var numberAnterior = 0
    
    var alertTextFiled: UITextField?
    override func viewDidLoad() {
        let perfilActual = UserDefaults.standard.string(forKey: "perfilActual") ?? "Default"
         self.txtPerfilSeleccion.setTitle(perfilActual, for: .normal)
        
        let perfilesAntes = UserDefaults.standard.stringArray(forKey: "perfilesAnteriores")
        perfilesAnteriores = perfilesAntes ?? [String](arrayLiteral: "","")
        
        let numberAntes = UserDefaults.standard.integer(forKey: "numberAnterior")
        numberAnterior = numberAntes 
        
        let perfilesLista = UserDefaults.standard.stringArray(forKey: "perfilesLista")
        perfiles = perfilesLista ?? [String]()
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
            
           if indexPath.section == 0 && indexPath.row == 0 {  txtPerfilSeleccion.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
                     let sheet = UIAlertController(title: "Seleccione un perfil", message: nil, preferredStyle: .actionSheet)
                     
                     let perfilDefault=UIAlertAction(title: "Default", style: .default){
                          (action) in self.txtPerfilSeleccion.setTitle("Default", for: .normal)
                         UserDefaults.standard.set("Default", forKey: "perfilActual")
                         if let index = self.tableView.indexPathForSelectedRow{
                         self.tableView.deselectRow(at: index, animated: true)
                         }
                      }
                      sheet.addAction(perfilDefault)
                     
                     for perfil in perfiles {
                         
                         let item=UIAlertAction(title: perfil, style: .default){
                                    (action) in
                            let lastPerfil = self.txtPerfilSeleccion.title(for: .normal)
                            self.perfilesAnteriores[self.numberAnterior] = lastPerfil ?? "Default"
                            UserDefaults.standard.set(self.perfilesAnteriores, forKey: "perfilesAnteriores")
                            if(self.numberAnterior == 0){
                                self.numberAnterior = 1
                               UserDefaults.standard.set(1, forKey: "numberAnterior")
                            }
                            else{
                                self.numberAnterior = 0
                                UserDefaults.standard.set(0, forKey: "numberAnterior")
                            }
                            
                            self.txtPerfilSeleccion.setTitle(perfil, for: .normal)

                                    UserDefaults.standard.set(perfil, forKey: "perfilActual")
                                    if let index = self.tableView.indexPathForSelectedRow{
                                    self.tableView.deselectRow(at: index, animated: true)
                                    }

                                    let unidad = UserDefaults.standard.string(forKey: perfil + "timelapse_unidadtiempo") ?? "Segundos"
                                    
                                    let lado = UserDefaults.standard.string(forKey: perfil + "timelapse_lado") ?? "Derecho"
                                    
                                    let time = UserDefaults.standard.string(forKey: perfil + "timelapse_time") ?? "60"
                                    
                                    UserDefaults.standard.set(time + " " + unidad.lowercased() + ", lado " + lado.lowercased(), forKey: "subtitleTimlepaseShortcut")
                                    self.updateShortcuts()
                                    //UserDefaults.standard.set("App", forKey: "joystick_desde")
                                }

                         sheet.addAction(item)
                     }
                    
                     let act_cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                         (action) in self.txtPerfilSeleccion.setTitle(self.txtPerfilSeleccion.title(for: .normal), for: .normal)
                         if let index = self.tableView.indexPathForSelectedRow{
                         self.tableView.deselectRow(at: index, animated: true)
                         }
                     }
                     sheet.addAction(act_cancelar)
                     present(sheet,animated: true, completion: nil)
            
           }
           if indexPath.section == 1 && indexPath.row == 0 {
               print("add")
            
            
            //1. Create the alert controller.
            let alert = UIAlertController(title: "Crea un perfil nuevo", message: nil, preferredStyle: .alert)

            //2. Add the text field. You can configure it however you need.
            alert.addTextField(configurationHandler: alertTextFiled)

            // 3. Grab the value from the text field, and print it when the user clicks OK.
            let okAction = UIAlertAction(title: "Agregar", style: .default, handler: self.okHandler)
            alert.addAction(okAction)
            
            let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
             alert.addAction(cancelAction)
            // 4. Present the alert.
            self.present(alert, animated: true, completion: nil)

            
            
           if let index = self.tableView.indexPathForSelectedRow{
           self.tableView.deselectRow(at: index, animated: true)
           }
       }
           if indexPath.section == 1 && indexPath.row == 1 {
               print("delete")
            let sheet = UIAlertController(title: "Eliminar un perfil", message: nil, preferredStyle: .actionSheet)
            for perfil in perfiles {
                      
                      let item=UIAlertAction(title: perfil, style: .destructive){
                        (action) in self.perfiles.remove(at: self.perfiles.firstIndex(of: perfil) ?? -1)
                            self.txtPerfilSeleccion.setTitle("Default", for: .normal)
                            UserDefaults.standard.set("Default", forKey: "perfilActual")
                        UserDefaults.standard.set(self.perfiles, forKey: "perfilesLista")

                        UserDefaults.standard.removeObject(forKey: perfil + "timeout")
                        UserDefaults.standard.removeObject(forKey: perfil + "joystick_orden")
                        UserDefaults.standard.removeObject(forKey: perfil + "timelapse_movimiento")
                        UserDefaults.standard.removeObject(forKey: perfil + "timelapse_unidadtiempo")
                        UserDefaults.standard.removeObject(forKey: perfil + "timelapse_lado")
                        UserDefaults.standard.removeObject(forKey: perfil + "timelapse_time")
                        UserDefaults.standard.removeObject(forKey: perfil + "joystick_desde")
                        UserDefaults.standard.removeObject(forKey: perfil + "loop_delaytime")
                        UserDefaults.standard.removeObject(forKey: perfil + "loop_unidadtiempo")
                        UserDefaults.standard.removeObject(forKey: perfil + "loop_unidadtiempoDetenerse")
                        UserDefaults.standard.removeObject(forKey: perfil + "loop_Detenerse")
                             }

                      sheet.addAction(item)
                  }
            let act_cancelar=UIAlertAction(title: "Cancelar", style: .cancel){
                (action) in sheet.dismiss(animated: true, completion: nil)
                   }
                   sheet.addAction(act_cancelar)
            present(sheet,animated: true, completion: nil)
           if let index = self.tableView.indexPathForSelectedRow{
           self.tableView.deselectRow(at: index, animated: true)
           }
       }
    
}

    func alertTextFiled(textField: UITextField){
        alertTextFiled=textField
        alertTextFiled?.placeholder="Nombre del perfil"
        
    }
    func okHandler(alert: UIAlertAction!)
    {
        let textField = self.alertTextFiled // Force unwrapping because we know it exists.
        let perfilNuevo = (textField?.text)!
        print(perfilNuevo)
        perfiles.append(perfilNuevo)
        UserDefaults.standard.set(perfiles, forKey: "perfilesLista")
        self.txtPerfilSeleccion.setTitle(perfilNuevo, for: .normal)
        UserDefaults.standard.set(perfilNuevo, forKey: "perfilActual")
        
        let unidad = UserDefaults.standard.string(forKey: perfilNuevo + "timelapse_unidadtiempo") ?? "Segundos"
        
        let lado = UserDefaults.standard.string(forKey: perfilNuevo + "timelapse_lado") ?? "Derecho"
        
        let time = UserDefaults.standard.string(forKey: perfilNuevo + "timelapse_time") ?? "60"
        
        UserDefaults.standard.set(time + " " + unidad.lowercased() + ", lado " + lado.lowercased(), forKey: "subtitleTimlepaseShortcut")
        
    }
    
    func updateShortcuts(){
        var perfilesAnteriores = [String](arrayLiteral: "","")
        let perfilesAntes = UserDefaults.standard.stringArray(forKey: "perfilesAnteriores")
        perfilesAnteriores = perfilesAntes ?? [String](arrayLiteral: "","")
        
        
        let subtitleTimelapse = UserDefaults.standard.string(forKey: "subtitleTimlepaseShortcut") ?? "60 segundos, lado: derecho"
        
        let timelaspeIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIcon.IconType.captureVideo)
        
        let timelapseItem = UIApplicationShortcutItem(type: "slider.app.SliderCamera.timelapse", localizedTitle: "Iniciar Timelapse", localizedSubtitle: subtitleTimelapse, icon: timelaspeIcon, userInfo: nil)
        
        let profileIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIcon.IconType.favorite)
        
        var secondProfile = UIApplicationShortcutItem(type: "slider.app.SliderCamera.profile2", localizedTitle: "", localizedSubtitle: nil, icon: profileIcon, userInfo: nil)
        
        var firstProfile = UIApplicationShortcutItem(type: "slider.app.SliderCamera.profile1", localizedTitle: "", localizedSubtitle: nil, icon: profileIcon, userInfo: nil)
        
        if(perfilesAnteriores[0] != ""){
            firstProfile = UIApplicationShortcutItem(type: "slider.app.SliderCamera.profile1", localizedTitle:perfilesAnteriores[0] , localizedSubtitle: "Establecer perfil", icon: profileIcon, userInfo: nil)
        }
        if(perfilesAnteriores[1] != ""){
            secondProfile = UIApplicationShortcutItem(type: "slider.app.SliderCamera.profile2", localizedTitle: perfilesAnteriores[1], localizedSubtitle: "Establecer perfil", icon: profileIcon, userInfo: nil)
        }
        if((perfilesAnteriores[1] != "")&&(perfilesAnteriores[0] != "")){
            UIApplication.shared.shortcutItems = [timelapseItem, firstProfile, secondProfile]
        }
        else if((perfilesAnteriores[1] == "")&&(perfilesAnteriores[0] != "")){
            UIApplication.shared.shortcutItems = [timelapseItem, secondProfile]
        }
        else if((perfilesAnteriores[1] != "")&&(perfilesAnteriores[0] == "")){
            UIApplication.shared.shortcutItems = [timelapseItem, firstProfile]
        }
        else if((perfilesAnteriores[1] == "")&&(perfilesAnteriores[0] == "")){
            UIApplication.shared.shortcutItems = [timelapseItem]
        }

    }
    
    
    @IBOutlet weak var txtPerfilSeleccion: UIButton!
    @IBAction func perfilSeleccion(_ sender: Any) {
        
      
    }
}
